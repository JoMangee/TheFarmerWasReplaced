# the_farmer_was_replaced

You will need utils.py.py for most part of the code
